<?php
session_start();
if (empty ($_SESSION['username'])){
    header("Location:/web_application/login/login.php");
    exit();
}else{
    echo "Hello ".$_SESSION['username'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Saved Links</title>
    <link rel="stylesheet" href="saved_links.css">
</head>

<body>
    <div class="header">
        <h1>Saved Links</h1>
    </div>
    
    <div class="gcse-search">
        <input type="text" id="search-input" placeholder="Search...">
        <button id="search-button">Search</button>
    </div>
    
    <div id="search-results" class="search-results"></div>
    
    <script>
   