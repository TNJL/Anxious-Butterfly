<?php
session_start();
include("dbsconnect.php");

//empty for now, was gonna use it to execute the delete function but I got a little confuse

?>