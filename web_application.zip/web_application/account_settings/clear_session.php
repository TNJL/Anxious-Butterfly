<?php
session_start();

$_SESSION["username"] = ""; //sets username to none/resets it so they can't revisit other sites associated with that specific username
session_destroy(); //gets rid of ONLY the SESSION data

?>

<!doctype html>
<html>
    <header>
        <title>account deleted</title>
    </header>
    <body>
        <h1>You have succesfully deleted your account!</h1>
        <button type ="button" onclick ="location.href='/web_application/login/login.php'">Log in page</button>
    </body>
</html>