<?php
session_start();
if (empty ($_SESSION['username'])){
    header("Location:/web_application/login/login.php");
    exit();
}
include 'dbsconnect.php';

$user_id = $_SESSION['id'];
$query = "DELETE FROM user_information WHERE id = '$user_id'";

$result = mysqli_query ($dbc, $query);

?>
<html>
    <body>
        <script>
            alert("Account Deleted Successfully");
            window.location.href='clear_session.php';
            
        </script>
    </body>
</html>