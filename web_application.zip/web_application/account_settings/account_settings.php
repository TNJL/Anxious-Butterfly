<?php
session_start();
if (empty ($_SESSION['username'])){
    header("Location:/web_application/login/login.php");
    exit();
}else{
    echo "Hello ".$_SESSION['username'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Settings</title>
    <link rel="stylesheet" href="account_settings.css">
    
    <!-- google fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cantarell:ital,wght@0,400;0,700;1,400;1,700&family=Dancing+Script:wght@400..700&family=Encode+Sans+Expanded:wght@100;200;300;400;500;600;700;800;900&family=Inconsolata:wght@200..900&family=Jersey+25&family=Jim+Nightshade&family=Josefin+Sans:ital,wght@0,100..700;1,100..700&family=Nanum+Gothic&family=Ojuju:wght@200..800&family=Quicksand:wght@300..700&family=Rubik+Doodle+Shadow&family=Sacramento&family=Workbench&display=swap" rel="stylesheet">
</head>

<header>
    <div class = "dropdown">
        <button onclick="drop()" class = "dropbtn">
            <img src="images/butterfly.png" alt="butterfly" class = "icon">
        </button>
        <div id ="dcontent" class = "dropdown_content"> <!-- placeholder -->
                <button><a href = "/web_application/homePage.php"><img src="/web_application/images/home.png" alt="home button" class = "icon"></a></button>
                <button><a href = "/web_application/useful_links/useful_links.php"><img src="/web_application/images/loupe.png" alt="search icon" class = "icon"></a></button>
                <button><a href="/web_application/Account_Menu/account_menu.php" class="button"><img src="/web_application/images/user.png" alt="Account gear icon"></a></button>
                <form action = "/web_application/logout.php" method = "POST">
                <button type = "submit"><img src="/web_application/images/logout.png" alt="logout Button" class = "icon"></button>
            </form>
        </div>
    </div>
    <h2>Anxious Butterfly</h2>
    <img src="/web_application/images/butterfly_beige.png" alt="beige anxious butterfly symbol" height ="100px" width = "100px">
</header>

<body>
    
    
    <!-- Try to center it afterwards -->
    
    <div class="button-container">
     <fieldset>
        <button onclick = "deleteAcc()" id = "delete" name = "delete">Delete Account?</button>
    </fieldset>
    </div>
    <!-- Script to confirm delete -->
    <script>
        function deleteAcc(){
            var confirm_delete = prompt('Type "delete" to confirm');
            if (confirm_delete == "delete"){
                window.location.href = "delete_account.php";
            }else{
                alert("Account was NOT deleted");
            }
        }
     
        function drop(){
        document.getElementById("dcontent").classList.toggle("show");
}
//Drop Down Menu
window.onclick = function(event){
    if (!event.target.matches('.dropbtn')){
        var dropdowns = document.getElementByClassName("dropdown_content");
        var i;
        for( i = 0; i < dropdowns.length; i++){
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.containts('show')){;
                openDropdown.classList.remove('show')
            }
        }
    }
}
    </script>
  
    </body>
</html>
