<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy | Anxious Butterfly</title>
    <link rel="stylesheet" href="privacy_policy.css">
</head>
<body>
    <header>
        <h1>Anxious Butterfly - Privacy Policy</h1>
    </header>

    <section>
        <h2>Introduction</h2>
        <p>Welcome to Anxious Butterfly, a mobile application designed to help you track and manage anxiety symptoms. Your privacy is important to us, and we are committed to protecting the personal information you share with us.</p>

        <h2>Information We Collect</h2>
        <p>We collect the following types of personal information:</p>
        <ul>
            <li><strong>Account Information:</strong> Information such as your name, email address, and username when you sign up or log in.</li>
            <li><strong>Usage Data:</strong> Information about how you use the app, including features accessed and interactions within the app.</li>
            <li><strong>Health Information:</strong> Information related to your anxiety levels and symptoms as you track them in the app.</li>
        </ul>

        <h2>How We Use Your Information</h2>
        <p>Your information is used to:</p>
        <ul>
            <li>Provide you with personalized anxiety tracking and management tools.</li>
            <li>Improve our app based on usage patterns and feedback.</li>
            <li>Communicate with you about updates, new features, and support services.</li>
        </ul>

        <h2>Data Protection</h2>
        <p>We implement industry-standard security measures to protect your data from unauthorized access, disclosure, alteration, or destruction. However, no data transmission over the internet or electronic storage system is 100% secure.</p>

        <h2>Third-Party Services</h2>
        <p>We do not share your personal data with third parties, except as necessary for the operation of the app or as required by law.</p>

        <h2>Your Rights</h2>
        <p>You have the right to:</p>
        <ul>
            <li>Access, correct, or delete your personal information.</li>
            <li>Opt-out of communications from us.</li>
            <li>Request a copy of the data we have collected about you.</li>
        </ul>

        <h2>Changes to This Privacy Policy</h2>
        <p>We may update this Privacy Policy from time to time. Any changes will be posted on this page, and the date at the bottom will reflect the last updated time.</p>

        <h2>Contact Us</h2>
        <p>If you have any questions or concerns about this Privacy Policy, please contact us at support@anxiousbutterfly.com.</p>
    </section>

    <footer>
        <p>&copy; 2024 Anxious Butterfly. All rights reserved.</p>
    </footer>
</body>
</html>
