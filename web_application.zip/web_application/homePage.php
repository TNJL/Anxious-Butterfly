<?php
session_start();

if(empty($_SESSION['username'])){ //makes the session unqiue by checking for username. If username is not present, disconnects the session
    header("Location: /web_application/login/login.php"); 
    exit();
}else{
    //fill in with whatever
}
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="homePage.css">
    <title>My PHP Website</title>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cantarell:ital,wght@0,400;0,700;1,400;1,700&family=Dancing+Script:wght@400..700&family=Encode+Sans+Expanded:wght@100;200;300;400;500;600;700;800;900&family=Inconsolata:wght@200..900&family=Jersey+25&family=Jim+Nightshade&family=Josefin+Sans:ital,wght@0,100..700;1,100..700&family=Nanum+Gothic&family=Ojuju:wght@200..800&family=Quicksand:wght@300..700&family=Rubik+Doodle+Shadow&family=Sacramento&family=Workbench&display=swap" rel="stylesheet">
</head>
<header>
    <div class = "dropdown">
        <button onclick="drop()" class = "dropbtn">
            <img src="images/butterfly.png" alt="butterfly" class = "icon">
        </button>
        <div id ="dcontent" class = "dropdown_content"> <!-- placeholder -->
                <button><img src="images/home.png" alt="home button" class = "icon"></button>
                <button><a href = "useful_links/useful_links.php"><img src="images/loupe.png" alt="search icon" class = "icon"></a></button>
                <button><a href="Account_Menu/account_menu.php" class="button"><img src="images/user.png" alt="Account gear icon"></a></button>
                <form action = "logout.php" method = "POST">
                <button type = "submit"><img src="images/logout.png" alt="logout Button" class = "icon"></button>
            </form>
        </div>
    </div>
    
    <img src="images/butterfly_beige.png" alt="beige anxious butterfly symbol" height ="100px" width = "100px">
</header>
<body>
    <div class = "pet">
        <div class = "bubble" id = "bubble"></div>
        <button onclick="quote('pet')">
        <img src = "images/blackcat_relax.png" alt = "pet" width ="350px" height ="350px" id = "user_pet" name = "user_pet">
        </button>
    </div>
    
    <main>
     <!-- this white space forces the footer down-->  
    </main>
    
<footer> <!-- Create a div class that removes the background highlight of these icons or at least make it pleasing to the eyes -->

    <!-- Button that when pressed, changes the picture of the cat to a picture of the cat eating (still in progress) -->
    <button class = "button" onclick=""> <!--does not have a function yet-->
        <img src = "images/salad.png" alt = "salad">
    </button>
    
    <!--Breathing function goes here, similar to how the cat has a random quote, this will make the cat tell the user on the different breathing technique -->
    <button class = "button" onclick="quote('breath')"> <!--does not have a function yet-->
        <img src = "images/breathing.png" alt = "breathing icon">
    </button>
    
    <!-- Music Corner -->
    <a href="/web_application/music_corner/music_corner.php" class="button" id = "btn_removal"><img src="images/musical_notes.png" alt="Music"></a>
</footer>

<!-- JavaScript for dropdown menu -->
<script>

function drop(){
    document.getElementById("dcontent").classList.toggle("show");
}

window.onclick = function(event){
    if (!event.target.matches('.dropbtn')){
        var dropdowns = document.getElementByClassName("dropdown_content");
        var i;
        for( i = 0; i < dropdowns.length; i++){
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.containts('show')){;
                openDropdown.classList.remove('show')
            }
        }
    }
}


function quote(type){
    let book = "images/blackcat_book.png";
    let original = document.getElementById("user_pet");
    let quotes = []; //empty array called quotes
    let original_store = original.src; //stores the original image within another original variable which then has the original photo, STAY WITH ME NOW, WHICH THEN IN THEORY REPLACES THE BOOK IMAGE WHICH REPLACES THE ORIGINAL PHOTO WHEN THE BREATHING ICON IS PRESSED
    
    if(type == "pet"){ //for pressing the pet
        quotes =[
            "meow meow",
            "I SAID MEOW MEOW",
            "DON'T MAKE ME START BARKING FRFR",
            "Don't you go stressing around, \nyou know stress gives you wrinkles right?",
            "Hey hey HEY, yes you!\nWhy are you so perfect?",
            "If I got a penny for everytime\nyou got back up, I'd be catllionaire!",
            "You did your best and that's all that matters.\nTomorrow is a new day so don't you worry!",
            "Breath in... hold it... slowly exhale. Feel better <?php echo $_SESSION['username'];?>?"
            ];
    }else if (type == "breath"){ //for pressing the breath icon
        quotes =[
            "just breath!",
            "Breath in.... breath out...\nbreath in... breath out. You got this <3"
            ];
        original.src = book; //replaces the original
        setTimeout(() =>{
            original.src = original_store; //once 9 second is over, grabs the orignally stored image
        },8000);
            
    }
    
    const rquotes = quotes[Math.floor(Math.random() * quotes.length)]; //RANDOMIZE THE QUOTES
    const bubble = document.getElementById("bubble");
    bubble.innerText = rquotes;
    bubble.style.display = "block"; //shows the quote

    setTimeout(()=>{
        bubble.style.display = "none"; //removes the quote after x amount of time
    },10000);
}



</script>

</body>
</html>