<?php
session_start();

$_SESSION["username"] = ""; //sets username to none/resets it so they can't revisit other sites associated with that specific username
session_destroy(); //gets rid of ONLY the SESSION data

?>

<!doctype html>
<html>
    <head>
        <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="logout.css">
    
    <!-- google fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cantarell:ital,wght@0,400;0,700;1,400;1,700&family=Dancing+Script:wght@400..700&family=Encode+Sans+Expanded:wght@100;200;300;400;500;600;700;800;900&family=Inconsolata:wght@200..900&family=Jersey+25&family=Jim+Nightshade&family=Josefin+Sans:ital,wght@0,100..700;1,100..700&family=Nanum+Gothic&family=Ojuju:wght@200..800&family=Quicksand:wght@300..700&family=Rubik+Doodle+Shadow&family=Sacramento&family=Workbench&display=swap" rel="stylesheet">
    </head>
    <header>
        <title>Anxious Butterfly</title>
    </header>
    <body>
        <h1>You have succesfully logged out, see you soon butterfly!</h1>
        <button type ="button" onclick ="location.href='/web_application/login/login.php'">Log in page</button>
    </body>
</html>