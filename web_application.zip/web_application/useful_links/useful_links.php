<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Useful Links</title>
    <link rel="stylesheet" href="useful_links.css">
</head>


<body>
    <div class="header">
        <h1>Useful Links</h1>
    </div>
    
    <div class="gcse-search">
        <input type="text" id="search-input" placeholder="Search...">
        <button id="search-button">Search</button>
    </div>
    
    <div id="search-results" class="search-results"></div>
    
    <script>
        function displaySearchResults(results) {
            const resultsContainer = document.getElementById('search-results');
            resultsContainer.innerHTML = ''; // Clear previous results

            results.forEach(result => {
                const button = document.createElement('button');
                button.textContent = result.title; // Use the title of the result
                button.onclick = () => {
                    window.open(result.link, '_blank'); // Open link in a new tab
                };
                resultsContainer.appendChild(button);
            });
        }

        // Trigger search on button click
        document.getElementById('search-button').addEventListener('click', function() {
            const query = document.getElementById('search-input').value;
            if (query) {
                const cx = '727843b8ab08e402d'; // Your Custom Search Engine ID
                const apiKey = 'AIzaSyDQUQt6QCJz21Mer4sazT57MmScNzYGpuc'; // Your API key
                const url = `https://www.googleapis.com/customsearch/v1?key=${apiKey}&cx=${cx}&q=${encodeURIComponent(query)}`;

                fetch(url)
                    .then(response => {
                        if (!response.ok) {
                            console.error('Network response was not ok:', response.statusText);
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        console.log(data); // Debugging: log the API response
                        if (data.items) {
                            const results = data.items.map(item => ({
                                title: item.title,
                                link: item.link
                            }));
                            displaySearchResults(results);
                        } else {
                            console.warn('No items found in the response.');
                            document.getElementById('search-results').innerHTML = '<p>No results found.</p>';
                        }
                    })
                    .catch(error => console.error('Error fetching search results:', error));
            } else {
                console.warn('No query entered.');
            }
        });
        
        
        
        
        function displaySearchResults(results) {
    const resultsContainer = document.getElementById('search-results');
    resultsContainer.innerHTML = ''; // Clear previous results

    results.forEach(result => {
        // Create a container for each result
        const resultContainer = document.createElement('div');
        resultContainer.style.display = 'flex'; // Use flex to align items horizontally
        resultContainer.style.alignItems = 'center'; // Center align the checkbox and button

        // Create the checkbox
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.style.marginRight = '10px'; // Space between checkbox and button

        // Create the button
        const button = document.createElement('button');
        button.textContent = result.title; // Use the title of the result
        button.onclick = () => {
            window.open(result.link, '_blank'); // Open link in a new tab
        };

        // Append checkbox and button to the result container
        resultContainer.appendChild(checkbox);
        resultContainer.appendChild(button);

        // Append result container to the results container
        resultsContainer.appendChild(resultContainer);
    });
}

//drop down menu

function drop(){
    document.getElementById("dcontent").classList.toggle("show");
}

window.onclick = function(event){
    if (!event.target.matches('.dropbtn')){
        var dropdowns = document.getElementByClassName("dropdown_content");
        var i;
        for( i = 0; i < dropdowns.length; i++){
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.containts('show')){;
                openDropdown.classList.remove('show')
            }
        }
    }
}

    </script>
</body>
</html>
