<?php
session_start(); // unique user session

    include('dbsconnect.php'); #connects to the dbconnect php which then connects to the database
    $user = mysqli_real_escape_string($dbc,trim($_POST['username'])); //grabs the id user from the login.php
    $pass = mysqli_real_escape_string($dbc,trim($_POST['password'])); //grabs the id pass from login.php
    
    
    # SHA2('$pass',256) --> formula to compare hashes 
    $query = "SELECT id, username, password, email, fName, lName, pp, birthday, date_created FROM user_information WHERE username = '$user' AND password = '$pass'"; #validates the username and password
    
    #runs query
    $result = mysqli_query ($dbc,$query);
    
    if(mysqli_num_rows($result)==1){ //see if there is a result from the user and password (if there is a result, allows user to login, if not, goes back to login page)
        $row = mysqli_fetch_array($result); //, MYSQLI_ASSOC
        
        #temporary storing user values as global variables to use later
        #Session syntax is how you store the variable, the row syntax is you grabbing and storing it from the database
        $_SESSION['id']=$row['id'];
        $_SESSION['fName'] = $row['fName']; 
        $_SESSION['username'] = $row['username'];
        $_SESSION['lName'] = $row['lName'];
        $_SESSION['bday'] = $row['birthday'];
        $_SESSION['creation'] = $row['date_created'];
        header("Location: /web_application/homePage.php");
            exit();
    }else{
            header("Location: login.php");
            exit();
        }
    
    
?>