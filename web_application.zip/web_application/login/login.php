<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="login.css">
    
    <!-- google fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cantarell:ital,wght@0,400;0,700;1,400;1,700&family=Dancing+Script:wght@400..700&family=Encode+Sans+Expanded:wght@100;200;300;400;500;600;700;800;900&family=Inconsolata:wght@200..900&family=Jersey+25&family=Jim+Nightshade&family=Josefin+Sans:ital,wght@0,100..700;1,100..700&family=Nanum+Gothic&family=Ojuju:wght@200..800&family=Quicksand:wght@300..700&family=Rubik+Doodle+Shadow&family=Sacramento&family=Workbench&display=swap" rel="stylesheet">
</head>

<body>
    <div class = "header">
    <h1 class = "hspaceL">Anxious</h1>
        <img src = "/web_application/images/butterfly_beige.png" alt = "Anxious Butterfly Logo">
    <h1 class = "hspaceR">Butterfly</h1>
    </div>
    <div class = "even">
        <!-- User/Email Name -->
        <form action="login_handle.php" method="POST"> <!--Post allows us to grab user's informatrion from the database -->
        <fieldset>
            <legend>
                <label for="username">Username</label>
            </legend>
            <input type="text" id="user" name="username" required> <!-- Take in account the ID and name to much up with the database!!!!!!!!!! -->

        </fieldset>

                <br>
                <br>
                
        <!-- Password Section -->
            <fieldset>
                <legend>
                    <label for="password">Password</label>
                </legend>
                <input type="password" id="pass" name="password" required>
            </fieldset>
        
        <!-- Login Button -->
            <button type="submit" class = "login" value ="Sign In" name = "submit">Login</button>
            <p >Create an Account For Free!!! <a href="/web_application/sign_up/sign_up.php">Sign up</a></p>
        </form>
        </div>
</body>
</html>