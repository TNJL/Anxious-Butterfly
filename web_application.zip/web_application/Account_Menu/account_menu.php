<?php
session_start();
if (empty ($_SESSION['username'])){
    header("Location:/web_application/login/login.php");
    exit();
}else{
    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="account_menu.css">
    
    <!-- google fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cantarell:ital,wght@0,400;0,700;1,400;1,700&family=Dancing+Script:wght@400..700&family=Encode+Sans+Expanded:wght@100;200;300;400;500;600;700;800;900&family=Inconsolata:wght@200..900&family=Jersey+25&family=Jim+Nightshade&family=Josefin+Sans:ital,wght@0,100..700;1,100..700&family=Nanum+Gothic&family=Ojuju:wght@200..800&family=Quicksand:wght@300..700&family=Rubik+Doodle+Shadow&family=Sacramento&family=Workbench&display=swap" rel="stylesheet">
</head>

<body>
    <img class="User_Icon" src="images/butterfly.png" alt="User Icon">
    <div class="username">Hello <?php echo $_SESSION['username']; ?></div> <!-- use the session variable name on the login_handler page -->
    <div class = "Button_Options">
            <button class = "Settings" onclick="window.location ='/web_application/account_settings/account_settings.php'";>Account Settings</button>
            <div class="Notifications">
                <span>Notifications Settings</span>
                <div class="toggle-container">
                    <input type="checkbox" id="notifications-toggle">
                        <label for="notifications-toggle" class="toggle-label">
                            <span class="toggle-slider"></span>
                        </label>
                </div>
            </div>
            <button class = "U_Links" onclick="window.location.href='https://infost490f2407.soisweb.uwm.edu/web_application/useful_links/useful_links.php';">Useful Links</button>
            <button class = "S_Links" onclick="window.location.href='https://infost490f2407.soisweb.uwm.edu/web_application/homePage.php';">Saved Links</button>
            <button class = "Privacy_Policy" onclick="window.location.href='https://infost490f2407.soisweb.uwm.edu/web_application/homePage.php';">Privacy Policy</button>
        </form>
    </div>
    
</body>
</html>