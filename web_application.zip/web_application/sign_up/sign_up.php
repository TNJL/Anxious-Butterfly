<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up Page</title>
    <link rel="stylesheet" href="sign_up.css">
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cantarell:ital,wght@0,400;0,700;1,400;1,700&family=Dancing+Script:wght@400..700&family=Encode+Sans+Expanded:wght@100;200;300;400;500;600;700;800;900&family=Inconsolata:wght@200..900&family=Jersey+25&family=Jim+Nightshade&family=Josefin+Sans:ital,wght@0,100..700;1,100..700&family=Nanum+Gothic&family=Ojuju:wght@200..800&family=Quicksand:wght@300..700&family=Rubik+Doodle+Shadow&family=Sacramento&family=Workbench&display=swap" rel="stylesheet">


</head>

<body>
    
    <!-- image and website name -->
    <div class = "header">
        <h1 class = "hspaceL">Anxious</h1>
            <img src = "/web_application/images/butterfly_beige.png" alt = "Anxious Butterfly Logo">
         <h1 class = "hspaceR">Butterfly</h1>
    </div>
    
    <!-- connection to the database -->
    <form action = "sign_uphandler.php" method = "POST"> 
    
    <!--User information needed to create an account -->
    
    <fieldset>
        <legend>
            <label for = "email">Please Enter Your Email</label>
        </legend>
        <input type = "email" id = "email" name = "email" placeholder = "example@outlook.com" required> <!-- id = email -->
    </fieldset>
    
    <fieldset>
        <legend>
            <label for = "username">Please Enter an username</label>
        </legend>
        <input type = "text" id = "user" name = "username" required> <!-- id = user -->
    </fieldset>
    
    <fieldset>
        <legend>
            <label for = "password">Please Enter a password</label>
        </legend>
        <input type = "password" id = "pass" name = "password" required> <!-- id = pass -->
    </fieldset>
    
    <fieldset>
        <legend>
            <label for = "confirm_pass">Please Confirm Your password</label>
        </legend>
        <input type = "password" id = "confirm_pass" name = "confirm_pass" required> <!-- id = confirm_pass -->
    </fieldset>
    
     <fieldset>
        <legend>
            <label for = "fname">Please Enter Your First Name</label>
        </legend>
        <input type = "text" id = "fname" name = "fname" placeholder = "John" required> <!-- id = fname -->
    </fieldset>
    
    <fieldset>
        <legend>
            <label for = "lname">Please Enter Your Last name</label>
        </legend>
        <input type = "text" id = "lname" name = "lname" placeholder ="Smith" required> <!-- id = lname -->
    </fieldset>
    
    <fieldset>
        <legend>
            <label for = "birthday">Please Enter Your Birthday</label>
        </legend>
        <input type = "date" id = "bday" name = "bday" required> <!-- id = bday -->
    </fieldset>
    
    <fieldset>
        <legend>
            <label for = "profile_pic">Upload a Profile Picture!</label>
        </legend>
        <input type = "file" id = "profile_pic" name = "profilepic" accept = "image/*"> <!-- id = profile_pic -->
    </fieldset>
    
    
    <button type = "submit" id = "sign_up" value = "Sign Up" name ="sign_up">Create Account</button> <!-- Click to add account to the database c; -->
    
    </form>
    
    <script>
        const pass = document.getElementById("pass");
        const pass_check = document.getElementById("confirm_pass");
        
        if pass == pass_check{
            
        }else{
            alert("Your passwords do not match!");
        }
    </script>
    
</body>

</html>