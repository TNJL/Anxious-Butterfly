<?php
session_start();
include("dbsconnect.php");

//storing user information (from the name tags from signup.php) into variables
$email = $_POST['email'];
$username = $_POST['username'];
$pass = $_POST['confirm_pass'];
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$bday = $_POST['bday'];
$pp = $_POST['profilepic'];

//query to run the script
$query = "INSERT into user_information (username, password, email, fName, lName, pp, birthday) VALUES ('$username', '$pass', '$email', '$fname', '$lname', '$pp', '$bday')";

//error checks
$result = mysqli_query($dbc,$query);

//if account is created successfully, prompts a good and happy message then redirects you back to the login page
if($result){
    header("location:/web_application/login/login.php");
}else{
    echo "there was an error creating your account!" . mysqli_error($dbc);  //DELETE the mysqli_error later, this is for me to see the errors if there is anything wrong. 
}

?>

<html>
    <body>
        
    </body>
</html>