<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Music Corner</title>
    <link rel="stylesheet" href="music_corner.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>  <!-- Include jQuery for AJAX -->
</head>
<header>
    <div class = "dropdown">
        <button onclick="drop()" class = "dropbtn">
            <img src="images/butterfly.png" alt="butterfly" class = "icon">
        </button>
        <div id ="dcontent" class = "dropdown_content"> <!-- placeholder -->
                <button><a href = "/web_application/homePage.php"><img src="/web_application/images/home.png" alt="home button" class = "icon"></a></button>
                <button><a href = "/web_application/useful_links/useful_links.php"><img src="/web_application/images/loupe.png" alt="search icon" class = "icon"></a></button>
                <button><a href="/web_application/Account_Menu/account_menu.php" class="button"><img src="/web_application/images/user.png" alt="Account gear icon"></a></button>
                <form action = "/web_application/logout.php" method = "POST">
                <button type = "submit"><img src="/web_application/images/logout.png" alt="logout Button" class = "icon"></button>
            </form>
        </div>
    </div>
    <img src="/web_application/images/butterfly_beige.png" alt="beige anxious butterfly symbol" height ="100px" width = "100px">
</header>
<body>
    <div class="header">
        <h1>Music Corner</h1>
    </div>
    
    <form action="new_song.php" method="post">
        <fieldset><legend>Add a new song to your list:</legend>
            <p><label>Song Name: <input type="text" name="name" size="20" required></label></p>
            <p><label>Artist: <input type="text" name="artist" size="20" required></label></p>
            <p align="center"><input type="submit" name="submit" value="Submit Song Information"></p>
        </fieldset>
    </form>
<script>
    function drop(){
    document.getElementById("dcontent").classList.toggle("show");
}

window.onclick = function(event){
    if (!event.target.matches('.dropbtn')){
        var dropdowns = document.getElementByClassName("dropdown_content");
        var i;
        for( i = 0; i < dropdowns.length; i++){
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.containts('show')){;
                openDropdown.classList.remove('show')
            }
        }
    }
}
</script>
</body>
</html>
