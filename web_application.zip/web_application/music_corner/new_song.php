<?php
session_start();  // Start the session to access session variables
include('dbsconnect.php');

// Check if the user is logged in by verifying session variables
if (!isset($_SESSION['username']) || !isset($_SESSION['id'])) {
    // If no session variables are set, prompt the user to log in
    echo "You need to log in first!";
    exit;
}

// Retrieve the logged-in user's information
$user = $_SESSION['username'];
$id = $_SESSION['id'];  // User ID from session

// Sanitize the form inputs
$name = mysqli_real_escape_string($dbc, trim($_POST['name']));
$artist = mysqli_real_escape_string($dbc, trim($_POST['artist']));

// Insert the song into the database
$query = "INSERT INTO music_files (music, artist, user_id) VALUES ('$name', '$artist', '$id')";
$result = mysqli_query($dbc, $query);

if ($result) {
    // Redirect to music_corner.php after successful insertion
    header("Location: https://infost490f2407.soisweb.uwm.edu/web_application/music_corner/music_corner.php");
    exit();  // Always call exit after header to stop further script execution
} else {
    // If there is an error with the insertion, output the error
    echo "Error inserting the song: " . mysqli_error($dbc);
}

?>
